﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CollegeManagement
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void loginbtn_Click(object sender, EventArgs e)
        {
            string Username = namebox.Text;
            string Password = passwordbox.Text;
            if (Username == "Admin" && Password == "student")
            {
                menuStrip1.Visible = true;
                panel1.Visible = false;
            }
            else
            {
                MessageBox.Show("invalid user id or password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void aDMISSIONToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void newAdmissionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            New_Admission m = new New_Admission();
            m.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure ? This will Delete Your Unsaved Date", "Comfirmation Daialog!", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK) ;
            Application.Exit();
        }

        private void eXITSYSTEMToolStripMenuItem1_Click(object sender, EventArgs e)
        {

            About_Us about = new About_Us();
            about.Show();
        }

        private void exitSystemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Delete_Student_Data delete = new Delete_Student_Data();
                delete.Show();
        }

        private void searchStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void sTUDENTDETAILSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            search_student search = new search_student();
            search.Show();
        }

        private void addTeacheToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Add_Teacher add = new Add_Teacher();
            add.Show();
        }

        private void searchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchTeacher search = new SearchTeacher();
                search.Show();
        }

        private void upgradeSemesterToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
        }

        private void fEESToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fees f = new fees();
            f.Show();   
        }
    }
}
