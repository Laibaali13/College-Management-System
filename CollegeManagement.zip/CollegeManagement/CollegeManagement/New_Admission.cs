﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CollegeManagement
{
    public partial class New_Admission : Form
    {
        OleDbConnection conn;
        OleDbCommand cmd;
        OleDbDataAdapter adapter;
        OleDbDataReader reader;
        DataTable DT;
        public New_Admission()
        {
            InitializeComponent();
        }
        void Getadmission()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\newadmission.accdb");
            DT = new DataTable();
            adapter = new OleDbDataAdapter("SELECT *FROM NewAdmission", conn);
            conn.Open();
            adapter.Fill(DT);
            conn.Close();
        }
        private void submitbtn_Click(object sender, EventArgs e)
        {
            try
            {
                string ID = textid.Text;
                string Name = namebox.Text;
                string FName = fnamebox.Text;
                string Gender = radioButton1.Checked ? radioButton1.Text : radioButton2.Text;
                DateTime DOB = dateTimePicker1.Value;
                string Email = emailbox.Text;
                string Department = comboBox1.Text;
                string Semester = comboBox2.Text;
                string Duration = comboBox3.Text;
                string Address = richTextBox1.Text;
                string Phone = mobilenobox.Text;

                using (OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\newadmission.accdb"))
                {
                    conn.Open();

                    using (OleDbCommand cmd = new OleDbCommand("INSERT INTO NewAdmission(ID, Name, FName, Gender, DOB, Email, Department, Semester, Duration, Address, Phone)" +
                          " VALUES (@id, @name, @fname, @gender, @dob, @email, @department, @semester, @duration, @address, @phone)", conn))
                    {
                        cmd.Parameters.AddWithValue("@id", ID);
                        cmd.Parameters.AddWithValue("@name", Name);
                        cmd.Parameters.AddWithValue("@fname", FName);
                        cmd.Parameters.AddWithValue("@gender", Gender);
                        cmd.Parameters.AddWithValue("@dob", DOB.ToString("yyyy-MM-dd")); // Convert DateTime to string in "yyyy-MM-dd" format
                        cmd.Parameters.AddWithValue("@email", Email);
                        cmd.Parameters.AddWithValue("@department", Department);
                        cmd.Parameters.AddWithValue("@semester", Semester);
                        cmd.Parameters.AddWithValue("@duration", Duration);
                        cmd.Parameters.AddWithValue("@address", Address);
                        cmd.Parameters.AddWithValue("@phone", Phone);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        conn.Close();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Student data submitted successfully!");
                        }
                        else
                        {
                            MessageBox.Show("Failed to submit student data.");
                        }
                    }
                }

               
            }
            catch (Exception)
            {
                MessageBox.Show("The Id alReady Exits. Plz enter The Different Registration ID. ");
            }



        }

        private void resetbtn_Click(object sender, EventArgs e)
        {
            // Clear the form fields
            textid.Text = "";
            namebox.Text = "";
            fnamebox.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            dateTimePicker1.Value = DateTime.Now;
            emailbox.Text = "";
            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox3.Text = "";
            richTextBox1.Text = "";
            mobilenobox.Text = "";
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void New_Admission_Load(object sender, EventArgs e)
        {
            Getadmission();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
