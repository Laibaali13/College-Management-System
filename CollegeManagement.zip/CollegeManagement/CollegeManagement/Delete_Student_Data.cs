﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace CollegeManagement
{
    public partial class Delete_Student_Data : Form
    {
        OleDbConnection conn;
        OleDbCommand cmd;
        OleDbDataReader reader;
        OleDbDataAdapter adapter;
        DataTable dt;

         private TextBox textid;
        private TextBox namebox;
        private TextBox fname;
        private TextBox  female ;
        private TextBox dateTimePicker1;
        private TextBox emailbox;
        private TextBox comboBox1;
        private TextBox comboBox2;
        private TextBox comboBox3;
        private TextBox richTextBox1;
        private TextBox mobilenobox;
        public Delete_Student_Data()
        {
            InitializeComponent();
          textid = new TextBox();
            namebox = new TextBox();
            fname = new TextBox();
            female = new TextBox();
            dateTimePicker1 = new TextBox();
            emailbox = new TextBox();
            comboBox1 = new TextBox();
            comboBox2 = new TextBox();
            comboBox3 = new TextBox();
            richTextBox1 = new TextBox();
            mobilenobox = new TextBox();



        }
        void Getremove()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\newadmission.accdb");
            dt = new DataTable();
            adapter = new OleDbDataAdapter("SELECT *FROM NewAdmission", conn);
            conn.Open();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }
        private void Delete_Student_Data_Load(object sender, EventArgs e)
        {
            Getremove();
        }

        private void deletbtn_Click(object sender, EventArgs e)
        {

             string query = "DELETE FROM NewAdmission WHERE ID = @id";
             cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@id", textid.Text);
             conn.Open();
             cmd.ExecuteNonQuery();
             conn.Close();
             MessageBox.Show("Delete the Student Data ");
             Getremove();
         
            }

        private void searchbox_TextChanged(object sender, EventArgs e)
        {
            OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\newadmission.accdb");
            if (conn.State == ConnectionState.Closed)
                conn.Open();
            OleDbCommand cmd = new OleDbCommand("select ID, Name, FName, Gender, DOB, Email, Department, Semester, Duration, Address, Phone from NewAdmission where ID like '%" + searchbox.Text + "%'", conn);
            OleDbDataAdapter adapter = new OleDbDataAdapter();
            DataTable dt = new DataTable();
            adapter.SelectCommand = cmd;
            dt.Clear();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            textid.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            namebox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            fname.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            female.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            dateTimePicker1.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            emailbox.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            comboBox1.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            comboBox2.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            comboBox3.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            richTextBox1.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
            mobilenobox.Text = dataGridView1.CurrentRow.Cells[10].Value.ToString();
        }

        private void update_Click(object sender, EventArgs e)
        {
            string query = "UPDATE NewAdmission " +
          "SET " +
          "Name = @name, " +
          "FName = @fname, " +
          "Gender = @gender, " +
          "DOB = @dob, " +
          "Email = @email, " +
           "Department = @department, " + 
           "Semester = @semester, " + 
           "Duration = @duration, " + 
           "Address = @address, " + 
           "Phone = @phone " +
           "WHERE " +
           "ID = @id"; // Added space before SET and WHERE and enclosed table name in square brackets
            cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@name", namebox.Text);
            cmd.Parameters.AddWithValue("@fname", fname.Text);
            cmd.Parameters.AddWithValue("@gender", female.Text);
            cmd.Parameters.AddWithValue("@dob", dateTimePicker1.Text);
            cmd.Parameters.AddWithValue("@email", emailbox.Text);
            cmd.Parameters.AddWithValue("@department", comboBox1.Text);
            cmd.Parameters.AddWithValue("@semester", comboBox2.Text);
            cmd.Parameters.AddWithValue("@duration", comboBox3.Text);
            cmd.Parameters.AddWithValue("@address", richTextBox1.Text);
            cmd.Parameters.AddWithValue("@phone", mobilenobox.Text);
            cmd.Parameters.AddWithValue("@id", textid.Text);
            // Check if the car with the specified RegNumber exists in the table
            query = "SELECT COUNT(*) FROM NewAdmission WHERE ID = @id";
            OleDbCommand cmdCount = new OleDbCommand(query, conn);
            cmdCount.Parameters.AddWithValue("@id", textid.Text);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Updated the Student Data Successfully");
            Getremove();

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
