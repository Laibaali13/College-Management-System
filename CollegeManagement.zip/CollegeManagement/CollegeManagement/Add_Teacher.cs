﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using static System.Net.Mime.MediaTypeNames;

namespace CollegeManagement
{
    public partial class Add_Teacher : Form
    {
        OleDbConnection conn;
        OleDbCommand cmd;
        OleDbDataAdapter adapter;
        OleDbDataReader reader;
        DataTable DT;
        public Add_Teacher()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void submitbtn_Click(object sender, EventArgs e)
        {
            try
            {
                string FullName = namebox.Text;
                string Gender = radioButton1.Checked ? radioButton1.Text : radioButton2.Text;
                DateTime DOB = dateTimePicker1.Value;
                string Email = emailbox.Text;
                string Semester = comboBox1.Text;
                string Programming = comboBox2.Text;             
                string Duration = comboBox3.Text;
                string Address = richTextBox1.Text;
                string Phone = mobilenobox.Text;

                using (OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\teacher.accdb"))
                {
                    conn.Open();

                    using (OleDbCommand cmd = new OleDbCommand("INSERT INTO teacher(FullName, Gender, DOB, Email, Semester, Programming, Duration, Address, Phone)" +
                          " VALUES (@name, @gender, @dob, @email, @semester, @programming, @duration, @address, @phone)", conn))
                    {
                        cmd.Parameters.AddWithValue("@name", FullName);
                        cmd.Parameters.AddWithValue("@gender", Gender);
                        cmd.Parameters.AddWithValue("@dob", DOB.ToString("yyyy-MM-dd")); // Convert DateTime to string in "yyyy-MM-dd" format
                        cmd.Parameters.AddWithValue("@email", Email);
                        cmd.Parameters.AddWithValue("@semester", Semester);
                        cmd.Parameters.AddWithValue("@programming", Programming);
                        cmd.Parameters.AddWithValue("@duration", Duration);
                        cmd.Parameters.AddWithValue("@address", Address);
                        cmd.Parameters.AddWithValue("@phone", Phone);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        conn.Close();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Teacher data submitted successfully!");
                        }
                        else
                        {
                            MessageBox.Show("Failed to submit student data.");
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }


        }

        private void resetbtn_Click(object sender, EventArgs e)
        {
            // Clear the form field
            namebox.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            dateTimePicker1.Value = DateTime.Now;
            emailbox.Text = "";
            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox3.Text = "";
            richTextBox1.Text = "";
            mobilenobox.Text = "";
        }
    }
}
